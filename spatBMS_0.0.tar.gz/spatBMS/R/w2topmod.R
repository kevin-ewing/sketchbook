w2topmod <-
function(tmo,wNr){
       binmat=tmo$bool_binary()
       KW=nrow(binmat); K=KW-wNr
       newbins=t(unique(as.data.frame(t(binmat[1:K,]))))
       dblbinsix=duplicated(as.data.frame(t(binmat[1:K,])))
       if(!any(dblbinsix)){
          return(topmod(nbmodels=tmo$nbmodels,nmaxregressors=K,bbeta=TRUE,lengthfixedvec=wNr,liks=tmo$lik(),
              ncounts=tmo$ncount(),modelbinaries=binmat[1:K,],betas=tmo$betas()[1:K,],betas2=tmo$betas2()[1:K,],fixed_vector=tmo$fixed_vec()))
       }
       # first look at unique topmodels and extract their statistics (likelihood, betas, betas2, etc.)
        else{
           newlik=tmo$lik()[!dblbinsix]
           newncount=tmo$ncount()[!dblbinsix]
           newbetas=tmo$betas()[1:K,!dblbinsix]
           newbetas2=tmo$betas2()[1:K,!dblbinsix]
           newfixedvec=binmat[-(1:K),!dblbinsix]
           #dblbins=binmat[1:K,dblbinsix]
           dblbins=binmat[1:K,dblbinsix,drop=FALSE]
                
           # now get aggregated statistics (lik, betas, etc); e.g. beta|w1, beta|w2, beta|w3...get pmp weighted (integrate W dimension out)
           for (i in 1:ncol(newbins)) {

             index.in.dblbins=!as.logical(colSums(abs(dblbins-newbins[,i])))
             if (any(index.in.dblbins)) {

               #thism=cbind(newbins[,i],dblbins)
               thism.ix.intmo=c(i,which(dblbinsix)[index.in.dblbins])
               thism.lik=tmo$lik()[thism.ix.intmo]
               thism.weights=exp(thism.lik)/sum(exp(thism.lik))
               newlik[i]=crossprod(thism.lik,thism.weights)[[1]]
               newncount[i]=sum(tmo$ncount()[thism.ix.intmo])
               newbetas[,i]=c(tmo$betas()[1:K,thism.ix.intmo]%*%thism.weights)
               newbetas2[,i]=c(tmo$betas2()[1:K,thism.ix.intmo]%*%thism.weights)
               newfixedvec[c(tmo$fixed_vector())[thism.ix.intmo],i]=1
             }
         }
       }

       return(topmod(nbmodels=tmo$nbmodels,nmaxregressors=K,bbeta=TRUE,lengthfixedvec=wNr,liks=newlik,ncounts=newncount,modelbinaries=newbins,betas=newbetas,betas2=newbetas2,fixed_vector=newfixedvec))
}

