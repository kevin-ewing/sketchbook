moranTest.bma <-
function (object, variants = "single", W, nmodel = NULL)
{
    require(BMS)
    require(spdep)
    if (!all(class(object) %in% c("bma", "spatFilt")))
        stop("Submit a spatFilt bma object")
    if (!variants %in% c("single", "double"))
        variants = "single"
    if (!"listw" %in% class(W))
        stop("Please submit a neighborhood matrix object of class 'listw'")
    lmList = lmListEV = moran = moranEV = list()
    wTmat = object$wTopModels
    dataM = as.matrix(object$X.data)
    WeightList = object$WList
    mMat = wTmat[1:(ncol(dataM) - 1), ]
    if (is.null(nmodel) || nmodel > ncol(wTmat))
        nmodel = ncol(wTmat)
    if (variants == "double") {
        for (i in 1:nmodel) {
            xMat1 = cbind(dataM[, names(which(mMat[, i] == 1))])
            xMat2 = cbind(dataM[, names(which(mMat[, i] == 1))],
                as.matrix(WeightList[[wTmat["W-Index", i]]]))
            lmList[[i]] = lm(dataM[, 1, drop = FALSE] ~ xMat1)
            lmListEV[[i]] = lm(dataM[, 1, drop = FALSE] ~ xMat2)
        }
        moran = lapply(lmList, function(x) lm.morantest(x, W))
        moranEV = lapply(lmListEV, function(x) lm.morantest(x,
            W))
    }
    else {
        for (i in 1:nmodel) {
            xMat2 = cbind(dataM[, names(which(mMat[, i] == 1))],
                as.matrix(WeightList[[wTmat["W-Index", i]]]))
            lmListEV[[i]] = lm(dataM[, 1, drop = FALSE] ~ xMat2)
        }
        moranEV = lapply(lmListEV, function(x) lm.morantest(x,
            W))
    }
    results = list(moran = moran, moranEV = moranEV)
    return(results)
}

