spatFilt.bms <-
function(X.data,WList,burn=1000,iter=NA,nmodel=100,mcmc="bd",g="UIP",mprior="random",mprior.size=NA,user.int=TRUE,
                start.value=NA,logfile=FALSE,logstep=10000) {
#                beta.save=TRUE,exact=NA,int=NA,printRes=NA,ask.set=NA,return.g.stats=NA,theta=NULL,prior.msize=NULL #deprecated function arguments, retained for compatibility with older versions

require(BMS);
# set this to true (cause of W stuff, we cannot use the inverse tricks speeding up the OLS calculations                 
force.full.ols=TRUE

 g.stats=FALSE
 # rule out hyper-g and EBL estimation, set g manually to bric in that case
 exList=list("ebl","EBL","hyper","HYPER")
 if(length(unlist(lapply(exList,function(x) grep(x,g))))>0){
    g="bric"
    print("Hyper-g prior / EBL currently not implemented for 'spatFilt.bms', g has been set to 'g=bric'.")
 }
 
 # rule out enumeration, set mcmc="bd" in that case
 exList=list("enum","enumerate")
 if(length(unlist(lapply(exList,function(x) grep(x,mcmc))))>0){
    mcmc="bd"
    print("Enumeration currently not implemented for 'spatFilt.bms', mcmc has been set to 'mcmc=bd'.")
 }

 


### getting data dimensions ####################
  if (class(X.data)[[1]]=="formula") { X.data=stats::model.frame(X.data) }

  if (any(is.na(X.data))) {
     X.data=na.omit(X.data)
     if (nrow(X.data)<3) {stop("Too few data observations. Please provide at least three data rows without NA entries.") }
     warning("Argument 'X.data' contains NAs. The corresponding rows have not been taken into account.")
  }                                                  

  
  N<-nrow(X.data)
  K=ncol(X.data)-1
  maxk=N-3  #maximum number of admissible k per model
  wNr=length(WList) # Number of W matrices
  K.filt=sapply(WList,function(x) ncol(x))   #list of length of filted Data matrices

############################################################################################################################################
#### User Checks: ##########################################################################################################################
############################################################################################################################################

                
  # check for deprecated arguments
#  if (!is.na(exact)) { warning("Function argument 'exact' has been deprecated, please refer to function 'estimates.bma' instead.") }
#  if (!is.na(int)) { mcmc=paste(mcmc,".int",sep=""); warning("Function argument 'int' has been deprecated, please add an 'int' to the argument 'mcmc' instead.") }
#  if (!is.na(printRes)) { user.int=printRes; warning("Function argument 'printRes' has been deprecated, please refer to the argument 'user.int' instead.") }  
#  if (!is.na(ask.set)) { warning("Function argument 'ask.set' has been deprecated, with no replacement.") }    
#  if (!is.na(return.g.stats)) { g.stats=return.g.stats; warning("Function argument 'return.g.stats' has been renamed into 'g.stats'.") }      
#  if (!is.null(theta)) { mprior=theta; warning("Function argument 'theta' has been renamed into 'mprior'.") }  
#  if (!is.null(prior.msize)) { mprior.size=prior.msize; warning("Function argument 'prior.msize' has been renamed into 'mprior.size'.") }      
  return.g.stats=g.stats; #theta=mprior; prior.msize=mprior.size
  
  if (nmodel[1]<=0|is.na(nmodel[1])) {dotop=FALSE;nmodel=0} else {dotop=TRUE}  

######################################################################################################################################      
    #assign the sampling procedure                                                                                              
   int=FALSE; is.enum=FALSE #int: whether interaction sampler is wanted; is.enum: whether the sampler is enumeration
   if (length(grep("int",mcmc,ignore.case=TRUE))) {int=TRUE}   
   
   if (length(grep("enum",mcmc,ignore.case=TRUE)))  {
      is.enum=TRUE; sampling=.iterenum
      if (K>maxk) sampling=.iterenum.KgtN
   } else if(length(grep("bd",mcmc,ignore.case=TRUE))){
    sampling=switch(int+1,.fls.samp,.fls.samp.int)
   } else {
    sampling=switch(int+1,.rev.jump,.rev.jump.int)
   }

######################################################################################################################################    
  # specific enumeration user checks & init
  if (is.enum) {      
     #check for a start.value index to start enumeration from seomewhere in between (and not do all possible models)  

     start.value2=0
     if (length(start.value)==1) { 
       start.value2=suppressWarnings(as.integer(start.value)) 
     if (any(is.na(start.value2))|start.value2[[1]]<K+5|start.value2[[1]]<0|start.value2[[1]]>=(2^K-1)) {
        start.value=0;start.value2=0
     }  else {
        #if startvalue is an integer index satysfying above conditions then convert it into a 'draw' to start from
        start.value=.enum_fromindex(start.value2)
        start.value=c(numeric(K-length(start.value)),start.value)   
     }
     } else { start.value=0 }      
     #   do all the other enumeration stuff
     burn=0;  int=FALSE; mcmc="enum"; is.enum=TRUE

     if (K>maxk) {lastindex=2^K-1-sum(choose(K,(N-2):K))} else lastindex=2^K-1
     if (is.na(iter)) {iter=lastindex-start.value2} #default iter is the rest to complete the enumeration from start.value
     iter=min(iter,2^K-1-start.value2); # don't do too much!                                                          


  } else {
     if (is.na(iter)) {iter=3000}; #if no enumeration and iter not given, set to default value 3000
  }

######################################################################################################################################
   # generate logfile if desired
    if(logfile!=FALSE){
        if (is.character(logfile)) {
          sfilename=logfile}
        else {
          sfilename="test.log"
        }
        if (nchar(sfilename)>0) file.create(sfilename)
        logfile=TRUE
      cat(as.character(Sys.time()),": starting loop ... \n",append=TRUE, file=sfilename)  #write one line
      if (logstep!=10000) fact=logstep else fact=max(floor((burn+iter)/100),logstep)
    }  
######################################################################################################################################
   #model prior Initialization
   
   #outsourced to stupid function for cleanliness
   pmplist=.choose.mprior(mprior,mprior.size,K=K)
   mprior=pmplist$mp.mode; 
   


######################################################################################################################################  
######################################################################################################################################  
 # subtract mean from all regressors as in FLS
  y<-as.matrix(X.data[,1])
  X<-as.matrix(X.data[,2:ncol(X.data)])
  y.mean=mean(y)
  y<-y-matrix(y.mean,N,1,byrow=TRUE)
  X.mean=colMeans(X)
  X<-X-matrix(X.mean,N,K,byrow=TRUE)

 
 # here demeaning of eigenvectors
  for(i in 1:wNr){
    Xmeans=colMeans(as.matrix(WList[[i]]))
    WList[[i]]=WList[[i]]-matrix(Xmeans,nrow(WList[[i]]),ncol(WList[[i]]),byrow=TRUE)
  }


 # multiply the whole matrix stuff out before going into the simulation loops
  XtX.big=crossprod(X)
  Xty.big=crossprod(X,y)
  yty = as.vector(crossprod(y))

 # user check:
  coreig=eigen(cor(X),symmetric=TRUE,only.values=TRUE)$values
  #  if (qr(XtX.big)$rank<(min(N,K)-1)) stop("The design matrix you provided seems to overly suffer from linear dependence; After adjusting for a constant, its rank is <min(N-1,K-1).\n This would almost certainly lead to problems in BMA sampling. Check whether you perhaps accidentally provided a constant term in X.data.") 
  if (sum(coreig>1e-10)<min(K,(N-1))) { force.full.ols=TRUE }
  
  
 # now create big XtX lists and Xty lists (for each W an own list)
 # we use Frisch Waugh  here
  resY=sapply(WList, function(x) lm(y~x)$res)
  LmList=list()
  for(i in 1:length(WList)){
    LmList[[i]]=apply(X,2,function(x) lm(x~as.matrix(WList[[i]]))$res)
  }

  XtX.bigList<-Xty.bigList<-list()
  for(i in 1:wNr){
        XtX.bigList[[i]]=crossprod(LmList[[i]])
        Xty.bigList[[i]]=crossprod(LmList[[i]],y)
  } 
  yty.big=apply(resY,2,crossprod) 
  

######################################################################################################################################
 # for the case that X contains interaction terms
  if(int){
      if(length(grep("#",colnames(X.data),fixed=TRUE))==0) stop("Please separate column names of interaction terms by # (e.g. A#B)")
      mPlus=.constr.intmat(X,K)
  }
  else{ mPlus<-NA }                                
  
######################################################################################################################################
    #gprior-Stuff Initialization

    # now initialize wNr gprior objects, for each object we have a different yty

    gprior.info=.choose.gprior(g,N,K,g.stats) # gprior.info is a list that summarizes info about the choice of the g-prior
    
    # null lik calculation
    nullVec=((1-N)/2)*log(yty.big)    # this is wrong!!

    lprobcalc=list()
    for(i in 1:wNr){
            if (gprior.info$gtype=="EBL")  {
               lprobcalc[[i]]=.lprob.eblocal.init(N=N,K=(K+K.filt[i]),yty=yty,return.g=gprior.info$return.g.stats,null.lik=nullVec[i]) 
            } else if (gprior.info$gtype=="hyper")  {
               lprobcalc[[i]]=.lprob.hyperg.init(N=N,K=(K+K.filt[i]),yty=yty,f21a=gprior.info$hyper.parameter,return.gmoments=gprior.info$return.g.stats,null.lik=nullVec[i]) 
            } else {
               lprobcalc[[i]]=.lprob.constg.init(g=gprior.info$g,N=N,K=(K+K.filt[i]),yty=yty,null.lik=nullVec[i]) 
            }   
    }

######################################################################################################################################
#The function Starter selects randomly a start matrix and runs a
#regression. From this regression, the
#start Design matrix is that for which the t-stats are >0.2. So we
#can circumvent starting from a very bad start point.
  wSampleOld=ceiling(runif(1,min=0,max=wNr))
  wdraw=numeric(wNr); wdraw[wSampleOld]=1
                 
  start.list=.starter(K,start.value,y=resY[,wSampleOld],N=N,XtX.big=XtX.bigList[[wSampleOld]],Xty.big=Xty.bigList[[wSampleOld]],X=LmList[[wSampleOld]])
  molddraw=start.list$molddraw; start.position=start.list$start.position
  kold=sum(molddraw)
  position=(1:K)[molddraw==1]

########################################################################################################################################
 


################################################################################################
#    Initializing                                                                              #
################################################################################################


  # initialize sampler-specific variables    ########################################
  # these are to select additional statistics (such as g)
  collect.otherstats=FALSE
  otherstats=numeric(0)
  add.otherstats=numeric(0)
  # initialize the vector for collecting the empirical shrinkage factor moments
  if (gprior.info$return.g.stats & !(gprior.info$is.constant)) { add.otherstats=gprior.info$shrinkage.moments; collect.otherstats=TRUE } 
  cumsumweights=iter

  if (collect.otherstats) {addup=.addup.mcmc.wotherstats} else {addup=.addup.mcmc}
  if (is.enum) {
    cumsumweights=0
    if (collect.otherstats) {addup=.addup.enum.wotherstats} else {addup=.addup.enum}
  }
  environment(addup) <- environment()
  ##################################################################################

 
 
  ##initialize model variables with starter model ###################################
     
  ols.object=.ols.terms2(positions=(1:K)[molddraw==1],yty=yty.big[[wSampleOld]],k=kold,N,K=K,XtX.big=XtX.bigList[[wSampleOld]],Xty.big=Xty.bigList[[wSampleOld]]) #OLS results from starter model

  lik.list=lprobcalc[[wSampleOld]]$lprob.all(ymy=ols.object$ymy, k=kold+K.filt[wSampleOld], bhat=ols.object$bhat, diag.inverse=ols.object$diag.inverse) #likelihood and expected values for starter model
  lprobold=lik.list$lprob
  b1=lik.list$b1new
  b2=lik.list$b2new
 
  ## calculate the posterior model probability for the first model
  pmpold=pmplist$pmp(ki=kold,mdraw=molddraw)
  ##################################################################################
  
  ## initialize top 10 function ####################################################

  #null.lik=((1-N)/2)*log(yty) # calculate Likelihood for NullModel
 

#  if (beta.save<0) {bbeta2=FALSE} else { bbeta2=beta.save }
  # set beta save manually to TRUE  cause I need to save at least the W-index variable 
  beta.save=TRUE
  topmods=topmod(nmaxregressors=(K+wNr),nbmodel=nmodel, lengthfixedvec=1,bbeta=beta.save)
           
  if (dotop) topmods$addmodel(mylik=pmpold+lprobold,vec01=c(molddraw,wdraw),vbeta=c(b1,NA),vbeta2=c(b2,NA),fixedvec=wSampleOld)
   # topmods$addmodel(mylik=pmp2,vec01=c(molddraw,wdraw),vbeta=c(b1,0),vbeta2=c((stdev^2+b1^2),0),fixedvec=wSampleOld)
 
  ##################################################################################

 
   


  ## Initialize the rest  ###########################################################
  null.count=0             #number the null model has been drawn
  models.visited=0         #how often a model has been accepted (in burn-ins and iterations)
  inccount=numeric(K)      #how often the respective covariate has been included
  msize=0                  #average model size
  k.vec=numeric(K)         #how often the respective model size has been accepted
  b1mo=numeric(K)          #holds aggregate first moment of all coefficients
  ab=numeric(K)            #Initialize them here
  b2mo=numeric(K)          #holds aggregate second moment of all coefficients
  bb=numeric(K)    
  Wcount=numeric(wNr)          
  possign=inccount         # the number of times the respective coefficent has been positive
  mnewdraw=numeric(K)      #holds the binary vector denoting the proposed model
  if (force.full.ols) {candi.is.full.object=TRUE} else {candi.is.full.object=FALSE} #candi.is.full: if TRUE, standard OLS, else OLS via Frisch-Waugh tricks
  bmo=numeric(4*K); bm=bmo #common placeholder for b1mo, b2mo, k.vec and possign
  if (is.enum) { addup() } # in case the sampler is enumeration then count the starting value as well (no burn-ins)


###############################################################################################################
###############################################################################################################













#############################################################################################
    set.seed(as.numeric(Sys.time()))              #Set Seed randomly for number generator
                                                 
    t1<-Sys.time()                                #Save time before going into the loop 
###########################################################################################
#START MAIN LOOP
###########################################################################################
for (i in 1:(burn+iter)){
  
      if(logfile){ if (i %% fact==0) { cat(as.character(Sys.time()),":",i,"current draw \n",append=TRUE, file=sfilename)} } #write one line  
    
##########################################################################################
#Start sampling program
###########################################################################################


# Regressor Sampling Start##################################################################################################################################
      #sample a model                                                                                           
      a=sampling(molddraw=molddraw,K=K,mPlus=mPlus,maxk=maxk,oldk=kold)
      mnewdraw=a$mnewdraw; positionnew=a$positionnew; knew=length(positionnew) 
    
      #calculate prior model prob
      pmpnew=pmplist$pmp(ki=knew,mdraw=mnewdraw) # get the (log) model prior prob

      if (!is.enum) {                                       
        if (int) {if (length(c(a$dropi,a$addi))>2|i<3|force.full.ols) {candi.is.full.object=TRUE} else {candi.is.full.object=FALSE}} 
        #candi.is.full.object = TRUE if there were multiple regs dropped or added due to interaction terms
                                        
        if (candi.is.full.object) {
            ols.candidate = .ols.terms2(positions=positionnew,yty=yty.big[[wSampleOld]],k=knew,N,K=K,XtX.big=XtX.bigList[[wSampleOld]],
                                        Xty.big=Xty.bigList[[wSampleOld]]) #in case of changing interaction terms, draw the big OLS stuff           
            ymy.candi =ols.candidate$ymy
        } else {
            ymy.candi=ols.object$child.ymy(a$addi,a$dropi,k=knew) #if standard sampling, use Frisch-Waugh to get the new ResidSS (faster)
        }

        
        lprobnew = lprobcalc[[wSampleOld]]$just.loglik(ymy.candi,c(knew+K.filt[wSampleOld])) # get the log-likelihood out of the ResidSS
        
        #Now decide whether to accept candidate draw
        accept.candi = as.logical(log(.Internal(runif(1,0,1)))< lprobnew-lprobold + pmpnew-pmpold)
        
      } else {
        accept.candi=TRUE
        candi.is.full.object=FALSE
      }      
 
    
      
      if(accept.candi){
          if (!candi.is.full.object) {
              # in case one has used Frisch-Waugh and the new model got accepted,
              # calculate the 'real' inverse in order not to make copying mistakes       
              ols.res = ols.object$mutate(addix=a$addi, dropix=a$dropi, newpos=positionnew, newk=knew)
          } else {
              ols.object = ols.candidate
              ols.res = ols.candidate$full.results()
          }
          
          lik.list = lprobcalc[[wSampleOld]]$lprob.all(ols.res$ymy, c(knew+K.filt[wSampleOld]), ols.res$bhat, ols.res$diag.inverse)

          
          lprobold=lik.list$lprob
          position = positionnew
          pmpold=pmpnew # get posterior odds for new model  if accepted
          molddraw=mnewdraw
          kold=knew   
          models.visited=models.visited+1 #does not account for revisiting models
      }
 
 
 # W Sampling Start##################################################################################################################################
      wSampleNew=(1:wNr)[-c(wSampleOld)][ceiling((runif(1)*(wNr-1)))] # 
      #wSampleNew=ceiling(runif(1,min=0,max=wNr))
      
      
      # not necessary to calculate PMPs since we do not sample the Ws
         # pmpnew=pmplist$pmp(ki=kold,mdraw=molddraw) # get the (log) model prior prob

   
      # k is kold, only W changes to wSampleNew!!!
      ols.candidate = .ols.terms2(positions=position,yty=yty.big[[wSampleNew]],k=kold,N,K=K,XtX.big=XtX.bigList[[wSampleNew]],
                                        Xty.big=Xty.bigList[[wSampleNew]]) #in case of changing interaction terms, draw the big OLS stuff           
      ymy.candi =ols.candidate$ymy
      lprobnew = lprobcalc[[wSampleNew]]$just.loglik(ymy.candi,c(kold+K.filt[wSampleNew])) # get the log-likelihood out of the ResidSS

      # Now decide whether to accept candidate draw
       # accept.candi = as.logical(log(.Internal(runif(1,0,1)))< lprobnew-lprobold + pmpnew-pmpold)
      accept.candi = as.logical(log(.Internal(runif(1,0,1)))< lprobnew-lprobold )
        #
   
   
  if(accept.candi){
          ols.object = ols.candidate
          ols.res = ols.candidate$full.results()
          wSampleOld=wSampleNew
          lik.list = lprobcalc[[wSampleOld]]$lprob.all(ols.res$ymy, c(kold+K.filt[wSampleNew]), ols.res$bhat, ols.res$diag.inverse)
          lprobold=lik.list$lprob
          #position = positionnew   # no position change and no pmp change
          #pmpold=pmpnew # get posterior odds for new model  if accepted
          #molddraw=mnewdraw
          #kold=knew   
          models.visited=models.visited+1 #does not account for revisiting models

  }

 

 

# Collect Posterior Draws
########################################################################
    if (i>burn){   
          b1=lik.list$b1new; b2=lik.list$b2new
          
          addup() #addup does iterative, cumulative sums of quantities of interest (betas, model size, etc.)      
          wdraw=numeric(wNr); wdraw[wSampleOld]=1
          Wcount[wSampleOld]=Wcount[wSampleOld]+1;
          # add log(lik)*p(M) to topmodels
          if (dotop)  topmods$addmodel(mylik=pmpold+lprobold,vec01=c(molddraw,wdraw),vbeta=c(b1,NA),vbeta2=c(b2,NA),fixedvec=wSampleOld)

    }
}
###########################################################################################
#END MAIN LOOP
###########################################################################################


###########################################################################################
   #adjust the topmod object and calculate all the betas after sampling
   #similar to having set bbeta=TRUE, and bbeta2=TRUE in the call to .top10 above
   #if (dotop) topmods=.topmod.as.bbetaT(topmods,gprior.info,X.data)

###########################################################################################

###########################################################################################
  
  timed<-difftime(Sys.time(),t1)

  # do aggregating calculations
  if (is.enum) {iter=iter+1; models.visited=models.visited+1}
  bmo=matrix(bmo,4,byrow=TRUE); b1mo=bmo[1,]; b2mo=bmo[2,]; k.vec=bmo[3,]; possign=bmo[4,]; rm(bmo)
  
  post.inf=.post.calc(gprior.info,add.otherstats,k.vec,null.count,X.data,topmods,b1mo,b2mo,iter,burn,inccount,models.visited,K,N,msize,timed,cumsumweights,mcmc,possign)



  # report disaggregated results
  wIdx=topmods$fixed_vec()
  tM=topmods$bool_binary()[1:(ncol(X.data)-1),]
  if(length(colnames(X.data)[-1])==nrow(tM)){
      rownames(tM)=colnames(X.data)[-1]
  }
  lt1=topmods$lik() - max(topmods$lik())    # do this to get only positive probabilities
  lt1=exp(lt1)/sum(exp(lt1))
  lt2=topmods$ncount()/sum(topmods$ncount())
  
   #rbind the probs to the tMmatrix
  tM=rbind(tM,wIdx,lt1,lt2)
  rownames(tM)[(nrow(tM)-2):nrow(tM)]=c("W-Index","PMP (Exact)","PMP (MCMC)") 
  if(length(topmods$bool())==ncol(tM)){
        colnames(tM)=topmods$bool()
  }
  
  
  
  result=list(info=post.inf$info,arguments=.construct.arglist(spatFilt.bms),topmod=w2topmod(topmods,wNr),wTopModels=tM,
              topmodOr=topmods,start.pos=sort(start.position),gprior.info=post.inf$gprior.info,mprior.info=pmplist,
              X.data=X.data,WList=WList, reg.names=post.inf$reg.names,bms.call=match.call(spatFilt.bms,sys.call(0)))
             
              
  class(result)=c("bma","spatFilt")
  
  # spatFilt extension
  names(Wcount)=names(WList)
  result$Wcount=Wcount
###########################################################################################  

  # print results to console
  if(user.int){
    print(result)
    print(timed)
    plot.bma(result) # do modelsize plot
  }
                                              
  return(invisible(result))
}

