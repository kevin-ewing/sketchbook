pmpW.bma <-
function(object){
    require(BMS);
    if(!all(class(object) %in% c("bma","spatFilt")))
        stop("Submit a spatFilt bma object")

    wTmat=object$wTopModels
    uN=unique(wTmat["W-Index",]);postSumE=sum(wTmat["PMP (Exact)",]);
    postSumV=sum(wTmat["PMP (MCMC)",]);
    pmp=NULL
    for(i in 1:length(uN)){
        idx=which(object$wTopModels["W-Index",]==uN[i])
        pmp=rbind(pmp,cbind(sum(object$wTopModels["PMP (Exact)",idx])/postSumE*100,
                            sum(object$wTopModels["PMP (MCMC)",idx])/postSumV*100))
    }

    colnames(pmp)=c("PMP (Exact)", "PMP (MCMC)")
    # rbind the matrices receiving zero posterior support for completeness
    rdx=which(!c(1:length(object$WList)) %in% uN)
    if(length(rdx)>0){
        pmp=rbind(pmp,matrix(0,ncol=2,nrow=length(rdx)))
        rownames(pmp)=names(object$WList)[c(uN,rdx)]
    }
    else{
        rownames(pmp)=names(object$WList)[uN]
    }  
    return(pmp)
}

